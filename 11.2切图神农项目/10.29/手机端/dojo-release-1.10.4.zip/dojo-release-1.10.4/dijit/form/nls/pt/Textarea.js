//>>built
define("dijit/form/nls/pt/Textarea",({iframeEditTitle:"editar área",iframeFocusTitle:"editar quadro da área"}));
