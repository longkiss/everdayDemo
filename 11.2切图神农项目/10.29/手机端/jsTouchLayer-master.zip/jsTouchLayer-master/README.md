#JS Touch Layer

JS Touch Layer is a javascript framework that abstracts away the decision of what the gesture is. It will decide for you if a tap is a tap, or a swipe is a swipe. Allowing you to bind your functions to these events without any worry.

JS Touch Layer may be freely distributed under the MIT license.

CAUTION: this is far from production ready and should be highly tested / modified before being such.

ToDo:

- Add gestures: Pinch / Spread
- Test on lots of devices

v0.3.0

- Fixes for drag events.
- Added unbind functionality.
- Added grunt.js file.
- Added twofingerdrag event.

v0.2.1

- Fixed dragging sensitivity.

v0.2.0

- Added mouse event fallback.
- Added minified version.

v0.1.0

- Initial Build of project.
