<?php
$idArray[0]=1;
?>