<?php
$cfg_disable_funs = 'phpinfo,eval,exec,passthru,shell_exec,system,proc_open,popen,curl_exec,curl_multi_exec,parse_ini_file,show_source,file_put_contents';
$cfg_disable_tags = 'php';
$cfg_basehost = 'http://qxu1780340062.my3w.com';
$cfg_cmspath = '';
$cfg_cookie_encode = 'wPPBhlt20UbNXYSLmUULPaIDV3qxxg';
$cfg_indexurl = '/';
$cfg_backup_dir = 'backupdata';
$cfg_indexname = '主页';
$cfg_webname = '佛山市国汇模具压铸科技有限公司';
$cfg_adminemail = '2859705589@qq.com';
$cfg_html_editor = 'ckeditor';
$cfg_arcdir = '/a';
$cfg_medias_dir = '/uploads';
$cfg_ddimg_width = 240;
$cfg_ddimg_height = 180;
$cfg_domain_cookie = '';
$cfg_imgtype = 'jpg|gif|png';
$cfg_softtype = 'zip|gz|rar|iso|doc|xsl|ppt|wps';
$cfg_mediatype = 'swf|mpg|mp3|rm|rmvb|wmv|wma|wav|mid|mov';
$cfg_specnote = 6;
$cfg_list_symbol = ' > ';
$cfg_notallowstr = '非典|艾滋病|阳痿';
$cfg_replacestr = '她妈|它妈|他妈|你妈|去死|贱人';
$cfg_feedbackcheck = 'N';
$cfg_keyword_replace = 'Y';
$cfg_fck_xhtml = 'N';
$cfg_df_style = 'guohui2';
$cfg_multi_site = 'N';
$cfg_dede_log = 'N';
$cfg_powerby = 'Copyright &copy; 2002-2011 DEDECMS. 织梦科技 版权所有';
$cfg_arcsptitle = 'N';
$cfg_arcautosp = 'N';
$cfg_arcautosp_size = 5;
$cfg_auot_description = 240;
$cfg_ftp_host = '';
$cfg_ftp_port = 21;
$cfg_ftp_user = '';
$cfg_ftp_pwd = '';
$cfg_ftp_root = '/';
$cfg_ftp_mkdir = 'N';
$cfg_feedback_ck = 'Y';
$cfg_list_son = 'Y';
$cfg_mb_open = 'N';
$cfg_mb_album = 'Y';
$cfg_mb_upload = 'Y';
$cfg_mb_upload_size = 1024;
$cfg_mb_sendall = 'Y';
$cfg_mb_rmdown = 'Y';
$cfg_cli_time = 8;
$cfg_mb_addontype = 'swf|mpg|mp3|rm|rmvb|wmv|wma|wav|mid|mov|zip|rar|doc|xsl|ppt|wps';
$cfg_mb_max = 500;
$cfg_keyword_like = 'N';
$cfg_index_max = 10000;
$cfg_index_cache = 86400;
$cfg_tplcache = 'Y';
$cfg_tplcache_dir = '/data/tplcache';
$cfg_makesign_cache = 'N';
$cfg_rm_remote = 'Y';
$cfg_arc_dellink = 'N';
$cfg_arc_autopic = 'Y';
$cfg_arc_autokeyword = 'Y';
$cfg_title_maxlen = 60;
$cfg_album_width = 800;
$cfg_check_title = 'Y';
$cfg_album_row = 3;
$cfg_album_col = 4;
$cfg_album_pagesize = 12;
$cfg_album_style = 2;
$cfg_album_ddwidth = 200;
$cfg_mb_notallow = 'www,bbs,ftp,mail,user,users,admin,administrator';
$cfg_mb_idmin = 3;
$cfg_mb_pwdmin = 3;
$cfg_mb_pwdtype = '32';
$cfg_md_idurl = 'N';
$cfg_mb_rank = 10;
$cfg_feedback_time = 30;
$cfg_feedback_numip = 30;
$cfg_md_mailtest = 'N';
$cfg_mb_spacesta = -10;
$cfg_vdcode_member = 'Y';
$cfg_mb_cktitle = 'Y';
$cfg_mb_editday = 7;
$cfg_caicai_sub = 2;
$cfg_caicai_add = 2;
$cfg_feedback_add = 5;
$cfg_feedback_sub = 5;
$cfg_search_max = 50000;
$cfg_search_maxrc = 300;
$cfg_search_time = 3;
$cfg_baidunews_limit = '100';
$cfg_updateperi = '15';
$cfg_sendmail_bysmtp = 'Y';
$cfg_smtp_server = 'smtp.qq.com';
$cfg_smtp_port = '25';
$cfg_smtp_usermail = 'desdev@vip.qq.com';
$cfg_smtp_user = 'desdev';
$cfg_smtp_password = '7260444huxiao';
$cfg_online_type = 'nps';
$cfg_upload_switch = 'Y';
$cfg_allsearch_limit = '1';
$cfg_rewrite = 'N';
$cfg_delete = 'Y';
$cfg_keywords = '';
$cfg_description = '';
$cfg_beian = '';
$cfg_need_typeid2 = 'Y';
$cfg_cache_type = 'id';
$cfg_max_face = 50;
$cfg_typedir_df = 'Y';
$cfg_makeindex = 'N';
$cfg_make_andcat = 'N';
$cfg_make_prenext = 'Y';
$cfg_feedback_forbid = 'N';
$cfg_jump_once = 'Y';
$cfg_task_pwd = '';
$cfg_addon_domainbind = 'N';
$cfg_addon_domain = '';
$cfg_df_dutyadmin = 'admin';
$cfg_mb_allowncarc = 'Y';
$cfg_mb_allowreg = 'Y';
$cfg_mb_adminlock = 'N';
$cfg_sendarc_scores = 10;
$cfg_sendfb_scores = 3;
$cfg_mb_spaceallarc = 0;
$cfg_face_adds = 10;
$cfg_moreinfo_adds = 20;
$cfg_money_scores = 50;
$cfg_mb_wnameone = 'N';
$cfg_arc_dirname = 'Y';
$cfg_puccache_time = 36000;
$cfg_arc_click = -1;
$cfg_addon_savetype = 'ymd';
$cfg_qk_uploadlit = 'Y';
$cfg_login_adds = 2;
$cfg_userad_adds = 10;
$cfg_ddimg_full = 'N';
$cfg_ddimg_bgcolor = 0;
$cfg_replace_num = 2;
$cfg_uplitpic_cut = 'Y';
$cfg_album_mark = 'N';
$cfg_mb_feedcheck = 'N';
$cfg_mb_msgischeck = 'N';
$cfg_mb_reginfo = 'Y';
$cfg_remote_site = 'N';
$cfg_title_site = 'N';
$cfg_mysql_type = 'mysql';
$cfg_sphinx_article = 'N';
$cfg_sphinx_host = 'localhost';
$cfg_sphinx_port = 9312;
$cfg_memcache_enable = 'N';
$cfg_memcache_mc_defa = 'memcache://127.0.0.1:11211/default127';
$cfg_memcache_mc_oth = '';
$cfg_cross_sectypeid = 'N';
$cfg_digg_update = 0;
$cfg_feedback_guest = 'N';
?>