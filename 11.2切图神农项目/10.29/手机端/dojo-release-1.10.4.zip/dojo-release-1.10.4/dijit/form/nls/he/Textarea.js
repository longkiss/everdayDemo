//>>built
define("dijit/form/nls/he/Textarea",({iframeEditTitle:"אזור עריכה",iframeFocusTitle:"מסגרת אזור עריכה"}));
