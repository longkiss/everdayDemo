<?php
//数据库连接信息
$cfg_dbhost = 'qdm114543226.my3w.com';
$cfg_dbname = 'qdm114543226_db';
$cfg_dbuser = 'qdm114543226';
$cfg_dbpwd = 'long147852';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>